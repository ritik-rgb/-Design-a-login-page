package com.example.loginpage;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button b1, b2;
    EditText t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        t1 = findViewById(R.id.editTextText);
        t2 = findViewById(R.id.editTextText2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = t1.getText().toString();
                String s1 = t2.getText().toString();
                if (s.equals("trident") && s1.equals("finalexam")) {
                    Toast.makeText(MainActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, SuccessActivity.class);
                    startActivity(intent);
                    myNoti();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Invalid", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, TryAgainMainActivity.class);
                    startActivity(intent);
                    myNoti1();

                }
            }

        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText("");
                t2.setText("");
            }

        });

    }
    void myNoti() {

        NotificationManager notificationManager;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "notify_001");
        Intent intent = new Intent(this, TryAgainMainActivity.class);
        intent.putExtra("key", "Onto Second page");
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setAction(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(pendingIntent);

        builder.setSmallIcon(R.mipmap.ic_launcher_round);

        builder.setContentTitle("yes working fine");
        builder.setContentText("Valid");
        builder.setPriority(Notification.PRIORITY_MAX);
        builder.setAutoCancel(true);
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String chanelId = "notify_001";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel
                    (chanelId, "Chanel Ready", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(notificationChannel);
            builder.setChannelId(chanelId);
        }

        notificationManager.notify(10, builder.build());
    }
    void myNoti1() {

        NotificationManager notificationManager;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "notify_001");
        Intent intent = new Intent(this, TryAgainMainActivity.class);
        intent.putExtra("key", "Onto Second page");
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setAction(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(pendingIntent);

        builder.setSmallIcon(R.mipmap.ic_launcher_round);

        builder.setContentTitle("yes working fine");
        builder.setContentText("Invalid");
        builder.setPriority(Notification.PRIORITY_MAX);
        builder.setAutoCancel(true);
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String chanelId = "notify_001";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel
                    (chanelId, "Chanel Ready", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(notificationChannel);
            builder.setChannelId(chanelId);
        }

        notificationManager.notify(10, builder.build());
    }

}



